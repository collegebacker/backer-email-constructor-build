/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/plugin/controller.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/plugin/controller.ts":
/*!**********************************!*\
  !*** ./src/plugin/controller.ts ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
figma.skipInvisibleInstanceChildren = true;
console.clear();
const defaultSize = {
    width: 260,
    height: 300
};
const pluginFrameSize = defaultSize;
figma.showUI(__html__, pluginFrameSize);
const getSegments = (node) => {
    return node === null || node === void 0 ? void 0 : node.getStyledTextSegments(["fontName", "textDecoration", "textCase", "fills", "hyperlink", "listOptions"]);
};
const returnHeroContent = (node) => {
    const titleNode = node.findAll((child) => child.name === "title")[0];
    const textNode = node.findAll((child) => child.name === "text")[0];
    return {
        name: "hero",
        title: titleNode.characters,
        text: getSegments(textNode) || null
    };
};
const returnTextContent = (node) => {
    const textNode = node.findAll((child) => child.name === "text")[0];
    return {
        name: "text",
        text: getSegments(textNode)
    };
};
const returnFooter = () => {
    return {
        name: "footer"
    };
};
const returnHeadLogo = () => {
    return {
        name: "headlogo"
    };
};
const returnHighlightContent = (node) => __awaiter(this, void 0, void 0, function* () {
    var _a;
    const emojiNode = node.findAll((child) => child.name === "emoji")[0];
    const titleNode = node.findAll((child) => child.name === "title")[0];
    const textNode = node.findAll((child) => child.name === "text")[0];
    const buttonNode = node.findAll((child) => child.name === "button-link")[0];
    const emojiImage = yield (emojiNode === null || emojiNode === void 0 ? void 0 : emojiNode.exportAsync({
        format: "PNG",
        constraint: {
            type: "SCALE",
            value: 2
        }
    }));
    return {
        name: "highlight",
        emojiData: emojiImage || null,
        emojiName: (emojiNode === null || emojiNode === void 0 ? void 0 : emojiNode.characters) || null,
        title: (titleNode === null || titleNode === void 0 ? void 0 : titleNode.characters) || null,
        text: getSegments(textNode) || null,
        button: {
            label: (buttonNode === null || buttonNode === void 0 ? void 0 : buttonNode.characters) || null,
            href: ((_a = buttonNode === null || buttonNode === void 0 ? void 0 : buttonNode.hyperlink) === null || _a === void 0 ? void 0 : _a.value) || null
        }
    };
});
const returnEndingText = (node) => {
    const textNode = node.findAll((child) => child.name === "text")[0];
    return {
        name: "endingtext",
        text: getSegments(textNode) || null
    };
};
const returnButtons = (node) => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;
    const buttons = node.findAll((child) => child.name === "button");
    const buttonsText = node.findAll((child) => child.name === "button-link");
    const buttonsObj = {
        name: "buttons",
        items: [
            {
                label: ((_a = buttonsText[0]) === null || _a === void 0 ? void 0 : _a.characters) || null,
                href: ((_c = (_b = buttonsText[0]) === null || _b === void 0 ? void 0 : _b.hyperlink) === null || _c === void 0 ? void 0 : _c.value) || null,
                mode: ((_e = (_d = buttons[0]) === null || _d === void 0 ? void 0 : _d.variantProperties) === null || _e === void 0 ? void 0 : _e.mode) || null
            },
            {
                label: ((_f = buttonsText[1]) === null || _f === void 0 ? void 0 : _f.characters) || null,
                href: ((_h = (_g = buttonsText[1]) === null || _g === void 0 ? void 0 : _g.hyperlink) === null || _h === void 0 ? void 0 : _h.value) || null,
                mode: ((_k = (_j = buttons[1]) === null || _j === void 0 ? void 0 : _j.variantProperties) === null || _k === void 0 ? void 0 : _k.mode) || null
            }
        ]
    };
    return buttonsObj;
};
const returnTitle = (node) => {
    const titleNode = node.findAll((child) => child.name === "title")[0];
    return {
        name: "title",
        title: (titleNode === null || titleNode === void 0 ? void 0 : titleNode.characters) || null,
        size: node.variantProperties.size
    };
};
const returnImage = (node) => __awaiter(this, void 0, void 0, function* () {
    const imageData = yield node.children[0].exportAsync({
        format: "PNG",
        constraint: {
            type: "SCALE",
            value: 1.5
        }
    });
    return {
        name: "image",
        imageID: node.id,
        imageData: imageData
    };
});
const returnHeroImage = (node) => __awaiter(this, void 0, void 0, function* () {
    const imageNode = node.findAll((child) => child.name === "image-wrap")[0];
    const titleNode = node.findAll((child) => child.name === "title")[0];
    const imageData = yield imageNode.exportAsync({
        format: "PNG",
        constraint: {
            type: "SCALE",
            value: 2
        }
    });
    return {
        name: "heroimage",
        imageData: imageData || null,
        imageID: node.id,
        title: (titleNode === null || titleNode === void 0 ? void 0 : titleNode.characters) || null
    };
});
const returnTwoImages = (node) => __awaiter(this, void 0, void 0, function* () {
    const imageNodes = node.children[0].children;
    const imagesData = yield Promise.all(imageNodes.map((imageNode) => __awaiter(this, void 0, void 0, function* () {
        const imageData = yield imageNode.exportAsync({
            format: "PNG",
            constraint: {
                type: "SCALE",
                value: 1.5
            }
        });
        return {
            name: "image",
            imageID: imageNode.id,
            imageData: imageData
        };
    })));
    return {
        name: "twoimages",
        imagesData: yield imagesData
    };
});
const returnList = (node) => {
    const text = node.findAll((child) => child.name === "text")[0];
    const textSegments = getSegments(text);
    let listItemsCount = 0;
    let listItems = [[]];
    const isOrdered = textSegments[0].listOptions.type === "ORDERED";
    textSegments.forEach((segment) => {
        listItems[listItemsCount].push(segment);
        if (segment.characters.endsWith("\n")) {
            listItemsCount++;
            listItems.push([]);
        }
    });
    return {
        name: "list",
        listItems: listItems,
        isOrdered: isOrdered
    };
};
const chechkForSelection = () => {
    const selected = figma.currentPage.selection;
    if (selected.length > 1 || selected.length === 0 || selected[0].type !== "FRAME") {
        figma.ui.postMessage({
            type: "current-selection",
            isValid: false,
            message: "please select only one element"
        });
    }
    if (selected.length === 1 && selected[0].type === "FRAME") {
        figma.ui.postMessage({
            type: "current-selection",
            isValid: true,
            message: "You can convert the email now"
        });
    }
};
chechkForSelection();
figma.on("selectionchange", () => {
    console.log(figma.currentPage.selection);
    chechkForSelection();
});
figma.ui.onmessage = (msg) => __awaiter(this, void 0, void 0, function* () {
    if (msg.type === "convert-to-HTML") {
        figma.ui.resize(800, 600);
        const selection = figma.currentPage.selection[0];
        if (selection === undefined) {
            figma.notify("Please select one or more nodes");
            return;
        }
        const emailChildren = yield Promise.all(selection.children
            .map((child) => {
            switch (child.name) {
                case "hero-bckr-email-cmp":
                    return returnHeroContent(child);
                case "text-bckr-email-cmp":
                    return returnTextContent(child);
                case "highlight-bckr-email-cmp":
                    return returnHighlightContent(child);
                case "footer-bckr-email-cmp":
                    return returnFooter();
                case "endingtext-bckr-email-cmp":
                    return returnEndingText(child);
                case "buttons-bckr-email-cmp":
                    return returnButtons(child);
                case "title-bckr-email-cmp":
                    return returnTitle(child);
                case "headlogo-bckr-email-cmp":
                    return returnHeadLogo();
                case "image-bckr-email-cmp":
                    return returnImage(child);
                case "heroimage-bckr-email-cmp":
                    return returnHeroImage(child);
                case "twoimages-bckr-email-cmp":
                    return returnTwoImages(child);
                case "list-bckr-email-cmp":
                    return returnList(child);
            }
        })
            .filter(Boolean));
        console.log(emailChildren);
        if (emailChildren.length > 0) {
            figma.ui.postMessage({
                type: "figma-components",
                data: emailChildren
            });
        }
        if (emailChildren.length === 0) {
            figma.notify("Select a frame with the email components");
        }
    }
    if (msg.type === "show-notification") {
        figma.notify(msg.data.message);
    }
    if (msg.type === "reset") {
        console.log("reset");
        figma.ui.resize(defaultSize.width, defaultSize.height);
    }
    if (msg.type === "manual-resize") {
        figma.ui.resize(Math.round(msg.size.width), Math.round(msg.size.height));
    }
});
figma.currentPage.setRelaunchData({ open: "" });


/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BsdWdpbi9jb250cm9sbGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7UUFBQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTs7O1FBR0E7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDBDQUEwQyxnQ0FBZ0M7UUFDMUU7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSx3REFBd0Qsa0JBQWtCO1FBQzFFO1FBQ0EsaURBQWlELGNBQWM7UUFDL0Q7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLHlDQUF5QyxpQ0FBaUM7UUFDMUUsZ0hBQWdILG1CQUFtQixFQUFFO1FBQ3JJO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMkJBQTJCLDBCQUEwQixFQUFFO1FBQ3ZELGlDQUFpQyxlQUFlO1FBQ2hEO1FBQ0E7UUFDQTs7UUFFQTtRQUNBLHNEQUFzRCwrREFBK0Q7O1FBRXJIO1FBQ0E7OztRQUdBO1FBQ0E7Ozs7Ozs7Ozs7OztBQ2xGQTtBQUNBLDJCQUEyQiwrREFBK0QsZ0JBQWdCLEVBQUUsRUFBRTtBQUM5RztBQUNBLG1DQUFtQyxNQUFNLDZCQUE2QixFQUFFLFlBQVksV0FBVyxFQUFFO0FBQ2pHLGtDQUFrQyxNQUFNLGlDQUFpQyxFQUFFLFlBQVksV0FBVyxFQUFFO0FBQ3BHLCtCQUErQixxRkFBcUY7QUFDcEg7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNELG1DQUFtQyxXQUFXIiwiZmlsZSI6ImNvZGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHt9O1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSkge1xuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuIFx0XHR9XG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRpOiBtb2R1bGVJZCxcbiBcdFx0XHRsOiBmYWxzZSxcbiBcdFx0XHRleHBvcnRzOiB7fVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBnZXR0ZXIgfSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uciA9IGZ1bmN0aW9uKGV4cG9ydHMpIHtcbiBcdFx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG4gXHRcdH1cbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbiBcdH07XG5cbiBcdC8vIGNyZWF0ZSBhIGZha2UgbmFtZXNwYWNlIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDE6IHZhbHVlIGlzIGEgbW9kdWxlIGlkLCByZXF1aXJlIGl0XG4gXHQvLyBtb2RlICYgMjogbWVyZ2UgYWxsIHByb3BlcnRpZXMgb2YgdmFsdWUgaW50byB0aGUgbnNcbiBcdC8vIG1vZGUgJiA0OiByZXR1cm4gdmFsdWUgd2hlbiBhbHJlYWR5IG5zIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDh8MTogYmVoYXZlIGxpa2UgcmVxdWlyZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy50ID0gZnVuY3Rpb24odmFsdWUsIG1vZGUpIHtcbiBcdFx0aWYobW9kZSAmIDEpIHZhbHVlID0gX193ZWJwYWNrX3JlcXVpcmVfXyh2YWx1ZSk7XG4gXHRcdGlmKG1vZGUgJiA4KSByZXR1cm4gdmFsdWU7XG4gXHRcdGlmKChtb2RlICYgNCkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAmJiB2YWx1ZS5fX2VzTW9kdWxlKSByZXR1cm4gdmFsdWU7XG4gXHRcdHZhciBucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18ucihucyk7XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShucywgJ2RlZmF1bHQnLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2YWx1ZSB9KTtcbiBcdFx0aWYobW9kZSAmIDIgJiYgdHlwZW9mIHZhbHVlICE9ICdzdHJpbmcnKSBmb3IodmFyIGtleSBpbiB2YWx1ZSkgX193ZWJwYWNrX3JlcXVpcmVfXy5kKG5zLCBrZXksIGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gdmFsdWVba2V5XTsgfS5iaW5kKG51bGwsIGtleSkpO1xuIFx0XHRyZXR1cm4gbnM7XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIlwiO1xuXG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gXCIuL3NyYy9wbHVnaW4vY29udHJvbGxlci50c1wiKTtcbiIsInZhciBfX2F3YWl0ZXIgPSAodGhpcyAmJiB0aGlzLl9fYXdhaXRlcikgfHwgZnVuY3Rpb24gKHRoaXNBcmcsIF9hcmd1bWVudHMsIFAsIGdlbmVyYXRvcikge1xuICAgIGZ1bmN0aW9uIGFkb3B0KHZhbHVlKSB7IHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIFAgPyB2YWx1ZSA6IG5ldyBQKGZ1bmN0aW9uIChyZXNvbHZlKSB7IHJlc29sdmUodmFsdWUpOyB9KTsgfVxuICAgIHJldHVybiBuZXcgKFAgfHwgKFAgPSBQcm9taXNlKSkoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICBmdW5jdGlvbiBmdWxmaWxsZWQodmFsdWUpIHsgdHJ5IHsgc3RlcChnZW5lcmF0b3IubmV4dCh2YWx1ZSkpOyB9IGNhdGNoIChlKSB7IHJlamVjdChlKTsgfSB9XG4gICAgICAgIGZ1bmN0aW9uIHJlamVjdGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yW1widGhyb3dcIl0odmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxuICAgICAgICBmdW5jdGlvbiBzdGVwKHJlc3VsdCkgeyByZXN1bHQuZG9uZSA/IHJlc29sdmUocmVzdWx0LnZhbHVlKSA6IGFkb3B0KHJlc3VsdC52YWx1ZSkudGhlbihmdWxmaWxsZWQsIHJlamVjdGVkKTsgfVxuICAgICAgICBzdGVwKChnZW5lcmF0b3IgPSBnZW5lcmF0b3IuYXBwbHkodGhpc0FyZywgX2FyZ3VtZW50cyB8fCBbXSkpLm5leHQoKSk7XG4gICAgfSk7XG59O1xuZmlnbWEuc2tpcEludmlzaWJsZUluc3RhbmNlQ2hpbGRyZW4gPSB0cnVlO1xuY29uc29sZS5jbGVhcigpO1xuY29uc3QgZGVmYXVsdFNpemUgPSB7XG4gICAgd2lkdGg6IDI2MCxcbiAgICBoZWlnaHQ6IDMwMFxufTtcbmNvbnN0IHBsdWdpbkZyYW1lU2l6ZSA9IGRlZmF1bHRTaXplO1xuZmlnbWEuc2hvd1VJKF9faHRtbF9fLCBwbHVnaW5GcmFtZVNpemUpO1xuY29uc3QgZ2V0U2VnbWVudHMgPSAobm9kZSkgPT4ge1xuICAgIHJldHVybiBub2RlID09PSBudWxsIHx8IG5vZGUgPT09IHZvaWQgMCA/IHZvaWQgMCA6IG5vZGUuZ2V0U3R5bGVkVGV4dFNlZ21lbnRzKFtcImZvbnROYW1lXCIsIFwidGV4dERlY29yYXRpb25cIiwgXCJ0ZXh0Q2FzZVwiLCBcImZpbGxzXCIsIFwiaHlwZXJsaW5rXCIsIFwibGlzdE9wdGlvbnNcIl0pO1xufTtcbmNvbnN0IHJldHVybkhlcm9Db250ZW50ID0gKG5vZGUpID0+IHtcbiAgICBjb25zdCB0aXRsZU5vZGUgPSBub2RlLmZpbmRBbGwoKGNoaWxkKSA9PiBjaGlsZC5uYW1lID09PSBcInRpdGxlXCIpWzBdO1xuICAgIGNvbnN0IHRleHROb2RlID0gbm9kZS5maW5kQWxsKChjaGlsZCkgPT4gY2hpbGQubmFtZSA9PT0gXCJ0ZXh0XCIpWzBdO1xuICAgIHJldHVybiB7XG4gICAgICAgIG5hbWU6IFwiaGVyb1wiLFxuICAgICAgICB0aXRsZTogdGl0bGVOb2RlLmNoYXJhY3RlcnMsXG4gICAgICAgIHRleHQ6IGdldFNlZ21lbnRzKHRleHROb2RlKSB8fCBudWxsXG4gICAgfTtcbn07XG5jb25zdCByZXR1cm5UZXh0Q29udGVudCA9IChub2RlKSA9PiB7XG4gICAgY29uc3QgdGV4dE5vZGUgPSBub2RlLmZpbmRBbGwoKGNoaWxkKSA9PiBjaGlsZC5uYW1lID09PSBcInRleHRcIilbMF07XG4gICAgcmV0dXJuIHtcbiAgICAgICAgbmFtZTogXCJ0ZXh0XCIsXG4gICAgICAgIHRleHQ6IGdldFNlZ21lbnRzKHRleHROb2RlKVxuICAgIH07XG59O1xuY29uc3QgcmV0dXJuRm9vdGVyID0gKCkgPT4ge1xuICAgIHJldHVybiB7XG4gICAgICAgIG5hbWU6IFwiZm9vdGVyXCJcbiAgICB9O1xufTtcbmNvbnN0IHJldHVybkhlYWRMb2dvID0gKCkgPT4ge1xuICAgIHJldHVybiB7XG4gICAgICAgIG5hbWU6IFwiaGVhZGxvZ29cIlxuICAgIH07XG59O1xuY29uc3QgcmV0dXJuSGlnaGxpZ2h0Q29udGVudCA9IChub2RlKSA9PiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uKiAoKSB7XG4gICAgdmFyIF9hO1xuICAgIGNvbnN0IGVtb2ppTm9kZSA9IG5vZGUuZmluZEFsbCgoY2hpbGQpID0+IGNoaWxkLm5hbWUgPT09IFwiZW1vamlcIilbMF07XG4gICAgY29uc3QgdGl0bGVOb2RlID0gbm9kZS5maW5kQWxsKChjaGlsZCkgPT4gY2hpbGQubmFtZSA9PT0gXCJ0aXRsZVwiKVswXTtcbiAgICBjb25zdCB0ZXh0Tm9kZSA9IG5vZGUuZmluZEFsbCgoY2hpbGQpID0+IGNoaWxkLm5hbWUgPT09IFwidGV4dFwiKVswXTtcbiAgICBjb25zdCBidXR0b25Ob2RlID0gbm9kZS5maW5kQWxsKChjaGlsZCkgPT4gY2hpbGQubmFtZSA9PT0gXCJidXR0b24tbGlua1wiKVswXTtcbiAgICBjb25zdCBlbW9qaUltYWdlID0geWllbGQgKGVtb2ppTm9kZSA9PT0gbnVsbCB8fCBlbW9qaU5vZGUgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGVtb2ppTm9kZS5leHBvcnRBc3luYyh7XG4gICAgICAgIGZvcm1hdDogXCJQTkdcIixcbiAgICAgICAgY29uc3RyYWludDoge1xuICAgICAgICAgICAgdHlwZTogXCJTQ0FMRVwiLFxuICAgICAgICAgICAgdmFsdWU6IDJcbiAgICAgICAgfVxuICAgIH0pKTtcbiAgICByZXR1cm4ge1xuICAgICAgICBuYW1lOiBcImhpZ2hsaWdodFwiLFxuICAgICAgICBlbW9qaURhdGE6IGVtb2ppSW1hZ2UgfHwgbnVsbCxcbiAgICAgICAgZW1vamlOYW1lOiAoZW1vamlOb2RlID09PSBudWxsIHx8IGVtb2ppTm9kZSA9PT0gdm9pZCAwID8gdm9pZCAwIDogZW1vamlOb2RlLmNoYXJhY3RlcnMpIHx8IG51bGwsXG4gICAgICAgIHRpdGxlOiAodGl0bGVOb2RlID09PSBudWxsIHx8IHRpdGxlTm9kZSA9PT0gdm9pZCAwID8gdm9pZCAwIDogdGl0bGVOb2RlLmNoYXJhY3RlcnMpIHx8IG51bGwsXG4gICAgICAgIHRleHQ6IGdldFNlZ21lbnRzKHRleHROb2RlKSB8fCBudWxsLFxuICAgICAgICBidXR0b246IHtcbiAgICAgICAgICAgIGxhYmVsOiAoYnV0dG9uTm9kZSA9PT0gbnVsbCB8fCBidXR0b25Ob2RlID09PSB2b2lkIDAgPyB2b2lkIDAgOiBidXR0b25Ob2RlLmNoYXJhY3RlcnMpIHx8IG51bGwsXG4gICAgICAgICAgICBocmVmOiAoKF9hID0gYnV0dG9uTm9kZSA9PT0gbnVsbCB8fCBidXR0b25Ob2RlID09PSB2b2lkIDAgPyB2b2lkIDAgOiBidXR0b25Ob2RlLmh5cGVybGluaykgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLnZhbHVlKSB8fCBudWxsXG4gICAgICAgIH1cbiAgICB9O1xufSk7XG5jb25zdCByZXR1cm5FbmRpbmdUZXh0ID0gKG5vZGUpID0+IHtcbiAgICBjb25zdCB0ZXh0Tm9kZSA9IG5vZGUuZmluZEFsbCgoY2hpbGQpID0+IGNoaWxkLm5hbWUgPT09IFwidGV4dFwiKVswXTtcbiAgICByZXR1cm4ge1xuICAgICAgICBuYW1lOiBcImVuZGluZ3RleHRcIixcbiAgICAgICAgdGV4dDogZ2V0U2VnbWVudHModGV4dE5vZGUpIHx8IG51bGxcbiAgICB9O1xufTtcbmNvbnN0IHJldHVybkJ1dHRvbnMgPSAobm9kZSkgPT4ge1xuICAgIHZhciBfYSwgX2IsIF9jLCBfZCwgX2UsIF9mLCBfZywgX2gsIF9qLCBfaztcbiAgICBjb25zdCBidXR0b25zID0gbm9kZS5maW5kQWxsKChjaGlsZCkgPT4gY2hpbGQubmFtZSA9PT0gXCJidXR0b25cIik7XG4gICAgY29uc3QgYnV0dG9uc1RleHQgPSBub2RlLmZpbmRBbGwoKGNoaWxkKSA9PiBjaGlsZC5uYW1lID09PSBcImJ1dHRvbi1saW5rXCIpO1xuICAgIGNvbnN0IGJ1dHRvbnNPYmogPSB7XG4gICAgICAgIG5hbWU6IFwiYnV0dG9uc1wiLFxuICAgICAgICBpdGVtczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGxhYmVsOiAoKF9hID0gYnV0dG9uc1RleHRbMF0pID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5jaGFyYWN0ZXJzKSB8fCBudWxsLFxuICAgICAgICAgICAgICAgIGhyZWY6ICgoX2MgPSAoX2IgPSBidXR0b25zVGV4dFswXSkgPT09IG51bGwgfHwgX2IgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9iLmh5cGVybGluaykgPT09IG51bGwgfHwgX2MgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9jLnZhbHVlKSB8fCBudWxsLFxuICAgICAgICAgICAgICAgIG1vZGU6ICgoX2UgPSAoX2QgPSBidXR0b25zWzBdKSA9PT0gbnVsbCB8fCBfZCA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2QudmFyaWFudFByb3BlcnRpZXMpID09PSBudWxsIHx8IF9lID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfZS5tb2RlKSB8fCBudWxsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGxhYmVsOiAoKF9mID0gYnV0dG9uc1RleHRbMV0pID09PSBudWxsIHx8IF9mID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfZi5jaGFyYWN0ZXJzKSB8fCBudWxsLFxuICAgICAgICAgICAgICAgIGhyZWY6ICgoX2ggPSAoX2cgPSBidXR0b25zVGV4dFsxXSkgPT09IG51bGwgfHwgX2cgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9nLmh5cGVybGluaykgPT09IG51bGwgfHwgX2ggPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9oLnZhbHVlKSB8fCBudWxsLFxuICAgICAgICAgICAgICAgIG1vZGU6ICgoX2sgPSAoX2ogPSBidXR0b25zWzFdKSA9PT0gbnVsbCB8fCBfaiA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2oudmFyaWFudFByb3BlcnRpZXMpID09PSBudWxsIHx8IF9rID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfay5tb2RlKSB8fCBudWxsXG4gICAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICB9O1xuICAgIHJldHVybiBidXR0b25zT2JqO1xufTtcbmNvbnN0IHJldHVyblRpdGxlID0gKG5vZGUpID0+IHtcbiAgICBjb25zdCB0aXRsZU5vZGUgPSBub2RlLmZpbmRBbGwoKGNoaWxkKSA9PiBjaGlsZC5uYW1lID09PSBcInRpdGxlXCIpWzBdO1xuICAgIHJldHVybiB7XG4gICAgICAgIG5hbWU6IFwidGl0bGVcIixcbiAgICAgICAgdGl0bGU6ICh0aXRsZU5vZGUgPT09IG51bGwgfHwgdGl0bGVOb2RlID09PSB2b2lkIDAgPyB2b2lkIDAgOiB0aXRsZU5vZGUuY2hhcmFjdGVycykgfHwgbnVsbCxcbiAgICAgICAgc2l6ZTogbm9kZS52YXJpYW50UHJvcGVydGllcy5zaXplXG4gICAgfTtcbn07XG5jb25zdCByZXR1cm5JbWFnZSA9IChub2RlKSA9PiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uKiAoKSB7XG4gICAgY29uc3QgaW1hZ2VEYXRhID0geWllbGQgbm9kZS5jaGlsZHJlblswXS5leHBvcnRBc3luYyh7XG4gICAgICAgIGZvcm1hdDogXCJQTkdcIixcbiAgICAgICAgY29uc3RyYWludDoge1xuICAgICAgICAgICAgdHlwZTogXCJTQ0FMRVwiLFxuICAgICAgICAgICAgdmFsdWU6IDEuNVxuICAgICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgbmFtZTogXCJpbWFnZVwiLFxuICAgICAgICBpbWFnZUlEOiBub2RlLmlkLFxuICAgICAgICBpbWFnZURhdGE6IGltYWdlRGF0YVxuICAgIH07XG59KTtcbmNvbnN0IHJldHVybkhlcm9JbWFnZSA9IChub2RlKSA9PiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uKiAoKSB7XG4gICAgY29uc3QgaW1hZ2VOb2RlID0gbm9kZS5maW5kQWxsKChjaGlsZCkgPT4gY2hpbGQubmFtZSA9PT0gXCJpbWFnZS13cmFwXCIpWzBdO1xuICAgIGNvbnN0IHRpdGxlTm9kZSA9IG5vZGUuZmluZEFsbCgoY2hpbGQpID0+IGNoaWxkLm5hbWUgPT09IFwidGl0bGVcIilbMF07XG4gICAgY29uc3QgaW1hZ2VEYXRhID0geWllbGQgaW1hZ2VOb2RlLmV4cG9ydEFzeW5jKHtcbiAgICAgICAgZm9ybWF0OiBcIlBOR1wiLFxuICAgICAgICBjb25zdHJhaW50OiB7XG4gICAgICAgICAgICB0eXBlOiBcIlNDQUxFXCIsXG4gICAgICAgICAgICB2YWx1ZTogMlxuICAgICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgbmFtZTogXCJoZXJvaW1hZ2VcIixcbiAgICAgICAgaW1hZ2VEYXRhOiBpbWFnZURhdGEgfHwgbnVsbCxcbiAgICAgICAgaW1hZ2VJRDogbm9kZS5pZCxcbiAgICAgICAgdGl0bGU6ICh0aXRsZU5vZGUgPT09IG51bGwgfHwgdGl0bGVOb2RlID09PSB2b2lkIDAgPyB2b2lkIDAgOiB0aXRsZU5vZGUuY2hhcmFjdGVycykgfHwgbnVsbFxuICAgIH07XG59KTtcbmNvbnN0IHJldHVyblR3b0ltYWdlcyA9IChub2RlKSA9PiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uKiAoKSB7XG4gICAgY29uc3QgaW1hZ2VOb2RlcyA9IG5vZGUuY2hpbGRyZW5bMF0uY2hpbGRyZW47XG4gICAgY29uc3QgaW1hZ2VzRGF0YSA9IHlpZWxkIFByb21pc2UuYWxsKGltYWdlTm9kZXMubWFwKChpbWFnZU5vZGUpID0+IF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24qICgpIHtcbiAgICAgICAgY29uc3QgaW1hZ2VEYXRhID0geWllbGQgaW1hZ2VOb2RlLmV4cG9ydEFzeW5jKHtcbiAgICAgICAgICAgIGZvcm1hdDogXCJQTkdcIixcbiAgICAgICAgICAgIGNvbnN0cmFpbnQ6IHtcbiAgICAgICAgICAgICAgICB0eXBlOiBcIlNDQUxFXCIsXG4gICAgICAgICAgICAgICAgdmFsdWU6IDEuNVxuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIG5hbWU6IFwiaW1hZ2VcIixcbiAgICAgICAgICAgIGltYWdlSUQ6IGltYWdlTm9kZS5pZCxcbiAgICAgICAgICAgIGltYWdlRGF0YTogaW1hZ2VEYXRhXG4gICAgICAgIH07XG4gICAgfSkpKTtcbiAgICByZXR1cm4ge1xuICAgICAgICBuYW1lOiBcInR3b2ltYWdlc1wiLFxuICAgICAgICBpbWFnZXNEYXRhOiB5aWVsZCBpbWFnZXNEYXRhXG4gICAgfTtcbn0pO1xuY29uc3QgcmV0dXJuTGlzdCA9IChub2RlKSA9PiB7XG4gICAgY29uc3QgdGV4dCA9IG5vZGUuZmluZEFsbCgoY2hpbGQpID0+IGNoaWxkLm5hbWUgPT09IFwidGV4dFwiKVswXTtcbiAgICBjb25zdCB0ZXh0U2VnbWVudHMgPSBnZXRTZWdtZW50cyh0ZXh0KTtcbiAgICBsZXQgbGlzdEl0ZW1zQ291bnQgPSAwO1xuICAgIGxldCBsaXN0SXRlbXMgPSBbW11dO1xuICAgIGNvbnN0IGlzT3JkZXJlZCA9IHRleHRTZWdtZW50c1swXS5saXN0T3B0aW9ucy50eXBlID09PSBcIk9SREVSRURcIjtcbiAgICB0ZXh0U2VnbWVudHMuZm9yRWFjaCgoc2VnbWVudCkgPT4ge1xuICAgICAgICBsaXN0SXRlbXNbbGlzdEl0ZW1zQ291bnRdLnB1c2goc2VnbWVudCk7XG4gICAgICAgIGlmIChzZWdtZW50LmNoYXJhY3RlcnMuZW5kc1dpdGgoXCJcXG5cIikpIHtcbiAgICAgICAgICAgIGxpc3RJdGVtc0NvdW50Kys7XG4gICAgICAgICAgICBsaXN0SXRlbXMucHVzaChbXSk7XG4gICAgICAgIH1cbiAgICB9KTtcbiAgICByZXR1cm4ge1xuICAgICAgICBuYW1lOiBcImxpc3RcIixcbiAgICAgICAgbGlzdEl0ZW1zOiBsaXN0SXRlbXMsXG4gICAgICAgIGlzT3JkZXJlZDogaXNPcmRlcmVkXG4gICAgfTtcbn07XG5jb25zdCBjaGVjaGtGb3JTZWxlY3Rpb24gPSAoKSA9PiB7XG4gICAgY29uc3Qgc2VsZWN0ZWQgPSBmaWdtYS5jdXJyZW50UGFnZS5zZWxlY3Rpb247XG4gICAgaWYgKHNlbGVjdGVkLmxlbmd0aCA+IDEgfHwgc2VsZWN0ZWQubGVuZ3RoID09PSAwIHx8IHNlbGVjdGVkWzBdLnR5cGUgIT09IFwiRlJBTUVcIikge1xuICAgICAgICBmaWdtYS51aS5wb3N0TWVzc2FnZSh7XG4gICAgICAgICAgICB0eXBlOiBcImN1cnJlbnQtc2VsZWN0aW9uXCIsXG4gICAgICAgICAgICBpc1ZhbGlkOiBmYWxzZSxcbiAgICAgICAgICAgIG1lc3NhZ2U6IFwicGxlYXNlIHNlbGVjdCBvbmx5IG9uZSBlbGVtZW50XCJcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChzZWxlY3RlZC5sZW5ndGggPT09IDEgJiYgc2VsZWN0ZWRbMF0udHlwZSA9PT0gXCJGUkFNRVwiKSB7XG4gICAgICAgIGZpZ21hLnVpLnBvc3RNZXNzYWdlKHtcbiAgICAgICAgICAgIHR5cGU6IFwiY3VycmVudC1zZWxlY3Rpb25cIixcbiAgICAgICAgICAgIGlzVmFsaWQ6IHRydWUsXG4gICAgICAgICAgICBtZXNzYWdlOiBcIllvdSBjYW4gY29udmVydCB0aGUgZW1haWwgbm93XCJcbiAgICAgICAgfSk7XG4gICAgfVxufTtcbmNoZWNoa0ZvclNlbGVjdGlvbigpO1xuZmlnbWEub24oXCJzZWxlY3Rpb25jaGFuZ2VcIiwgKCkgPT4ge1xuICAgIGNvbnNvbGUubG9nKGZpZ21hLmN1cnJlbnRQYWdlLnNlbGVjdGlvbik7XG4gICAgY2hlY2hrRm9yU2VsZWN0aW9uKCk7XG59KTtcbmZpZ21hLnVpLm9ubWVzc2FnZSA9IChtc2cpID0+IF9fYXdhaXRlcih0aGlzLCB2b2lkIDAsIHZvaWQgMCwgZnVuY3Rpb24qICgpIHtcbiAgICBpZiAobXNnLnR5cGUgPT09IFwiY29udmVydC10by1IVE1MXCIpIHtcbiAgICAgICAgZmlnbWEudWkucmVzaXplKDgwMCwgNjAwKTtcbiAgICAgICAgY29uc3Qgc2VsZWN0aW9uID0gZmlnbWEuY3VycmVudFBhZ2Uuc2VsZWN0aW9uWzBdO1xuICAgICAgICBpZiAoc2VsZWN0aW9uID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIGZpZ21hLm5vdGlmeShcIlBsZWFzZSBzZWxlY3Qgb25lIG9yIG1vcmUgbm9kZXNcIik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgZW1haWxDaGlsZHJlbiA9IHlpZWxkIFByb21pc2UuYWxsKHNlbGVjdGlvbi5jaGlsZHJlblxuICAgICAgICAgICAgLm1hcCgoY2hpbGQpID0+IHtcbiAgICAgICAgICAgIHN3aXRjaCAoY2hpbGQubmFtZSkge1xuICAgICAgICAgICAgICAgIGNhc2UgXCJoZXJvLWJja3ItZW1haWwtY21wXCI6XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByZXR1cm5IZXJvQ29udGVudChjaGlsZCk7XG4gICAgICAgICAgICAgICAgY2FzZSBcInRleHQtYmNrci1lbWFpbC1jbXBcIjpcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJldHVyblRleHRDb250ZW50KGNoaWxkKTtcbiAgICAgICAgICAgICAgICBjYXNlIFwiaGlnaGxpZ2h0LWJja3ItZW1haWwtY21wXCI6XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByZXR1cm5IaWdobGlnaHRDb250ZW50KGNoaWxkKTtcbiAgICAgICAgICAgICAgICBjYXNlIFwiZm9vdGVyLWJja3ItZW1haWwtY21wXCI6XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByZXR1cm5Gb290ZXIoKTtcbiAgICAgICAgICAgICAgICBjYXNlIFwiZW5kaW5ndGV4dC1iY2tyLWVtYWlsLWNtcFwiOlxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmV0dXJuRW5kaW5nVGV4dChjaGlsZCk7XG4gICAgICAgICAgICAgICAgY2FzZSBcImJ1dHRvbnMtYmNrci1lbWFpbC1jbXBcIjpcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJldHVybkJ1dHRvbnMoY2hpbGQpO1xuICAgICAgICAgICAgICAgIGNhc2UgXCJ0aXRsZS1iY2tyLWVtYWlsLWNtcFwiOlxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmV0dXJuVGl0bGUoY2hpbGQpO1xuICAgICAgICAgICAgICAgIGNhc2UgXCJoZWFkbG9nby1iY2tyLWVtYWlsLWNtcFwiOlxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmV0dXJuSGVhZExvZ28oKTtcbiAgICAgICAgICAgICAgICBjYXNlIFwiaW1hZ2UtYmNrci1lbWFpbC1jbXBcIjpcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJldHVybkltYWdlKGNoaWxkKTtcbiAgICAgICAgICAgICAgICBjYXNlIFwiaGVyb2ltYWdlLWJja3ItZW1haWwtY21wXCI6XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByZXR1cm5IZXJvSW1hZ2UoY2hpbGQpO1xuICAgICAgICAgICAgICAgIGNhc2UgXCJ0d29pbWFnZXMtYmNrci1lbWFpbC1jbXBcIjpcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJldHVyblR3b0ltYWdlcyhjaGlsZCk7XG4gICAgICAgICAgICAgICAgY2FzZSBcImxpc3QtYmNrci1lbWFpbC1jbXBcIjpcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJldHVybkxpc3QoY2hpbGQpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KVxuICAgICAgICAgICAgLmZpbHRlcihCb29sZWFuKSk7XG4gICAgICAgIGNvbnNvbGUubG9nKGVtYWlsQ2hpbGRyZW4pO1xuICAgICAgICBpZiAoZW1haWxDaGlsZHJlbi5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICBmaWdtYS51aS5wb3N0TWVzc2FnZSh7XG4gICAgICAgICAgICAgICAgdHlwZTogXCJmaWdtYS1jb21wb25lbnRzXCIsXG4gICAgICAgICAgICAgICAgZGF0YTogZW1haWxDaGlsZHJlblxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGVtYWlsQ2hpbGRyZW4ubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICBmaWdtYS5ub3RpZnkoXCJTZWxlY3QgYSBmcmFtZSB3aXRoIHRoZSBlbWFpbCBjb21wb25lbnRzXCIpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGlmIChtc2cudHlwZSA9PT0gXCJzaG93LW5vdGlmaWNhdGlvblwiKSB7XG4gICAgICAgIGZpZ21hLm5vdGlmeShtc2cuZGF0YS5tZXNzYWdlKTtcbiAgICB9XG4gICAgaWYgKG1zZy50eXBlID09PSBcInJlc2V0XCIpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJyZXNldFwiKTtcbiAgICAgICAgZmlnbWEudWkucmVzaXplKGRlZmF1bHRTaXplLndpZHRoLCBkZWZhdWx0U2l6ZS5oZWlnaHQpO1xuICAgIH1cbiAgICBpZiAobXNnLnR5cGUgPT09IFwibWFudWFsLXJlc2l6ZVwiKSB7XG4gICAgICAgIGZpZ21hLnVpLnJlc2l6ZShNYXRoLnJvdW5kKG1zZy5zaXplLndpZHRoKSwgTWF0aC5yb3VuZChtc2cuc2l6ZS5oZWlnaHQpKTtcbiAgICB9XG59KTtcbmZpZ21hLmN1cnJlbnRQYWdlLnNldFJlbGF1bmNoRGF0YSh7IG9wZW46IFwiXCIgfSk7XG4iXSwic291cmNlUm9vdCI6IiJ9